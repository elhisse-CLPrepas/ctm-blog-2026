# README — Blog CTM Signature v9

## Objectif
Cette version pousse le blog vers une identité "magazine éditorial CTM signature".

## Améliorations principales
- couverture illustrée uniforme sur l'ensemble des pages principales
- nouveau visuel `cover-default-signature.svg`
- rubriques mises en avant par couleur mentale
- cartes d'articles plus premium et plus régulières
- accents couleur par rubrique sur accueil, catégories, archives et filtres
- continuité visuelle plus forte entre les différentes pages du blog

## Fichiers ajoutés
- `assets/blog-v9.css`
- `assets/blog-v9.js`
- `assets/img/cover-default-signature.svg`
- `cover-default-signature.svg`
- `assets/article-signature.css`
- `article-template-signature.html`
- `README-refonte-blog-v9-ctm-signature.md`

## Fichiers mis à jour
- `index.html`
- `categories/index.html`
- `archives/index.html`

## Important
Le ZIP fourni ne contient pas les vraies pages d'articles du blog.

La version v9 améliore donc réellement :
- la page d'accueil
- la page catégories
- la page archives
- la logique visuelle des cartes articles

Pour préparer l'étape suivante, un gabarit d'article premium a aussi été ajouté :
- `article-template-signature.html`
- `assets/article-signature.css`

## Déploiement
1. sauvegarder le dossier `/public_html/blog/`
2. remplacer les fichiers par ceux du ZIP v9
3. vérifier :
   - `/blog/`
   - `/blog/categories/`
   - `/blog/archives/`
4. tester la présence des vrais articles côté serveur
5. si nécessaire, adapter ensuite chaque fiche article réelle à partir du gabarit ajouté

## Résultat attendu
- blog plus haut de gamme
- identité CTM plus forte
- navigation plus lisible
- présentation plus crédible sur mobile et desktop
