@echo off
setlocal enabledelayedexpansion

REM ------------------------------------------------------------
REM CTM Blog V6 — Générateur meta.json + cover.webp (ONE-CLICK)
REM Placez ce fichier dans /blog/scripts/ puis double-cliquez.
REM ------------------------------------------------------------

REM Blog dir = dossier parent de /scripts/
set "SCRIPT_DIR=%~dp0"
for %%I in ("%SCRIPT_DIR%..") do set "BLOG_DIR=%%~fI"

REM Base URL (modifiez si besoin)
set "BASE_URL=https://clprepas.com/blog"

REM Python (si "python" ne marche pas, remplacez par le chemin complet)
set "PY=py"

echo.
echo ============================================
echo CTM Blog V6 - Generation meta.json (WRITE)
echo Blog dir : "%BLOG_DIR%"
echo Base URL : "%BASE_URL%"
echo ============================================
echo.

%PY% "%SCRIPT_DIR%generate-meta-v6.py" --blog-dir "%BLOG_DIR:\=/%" --base-url "%BASE_URL%" --write
echo.
echo Termine. Rapport : "%SCRIPT_DIR%meta-report.md"
echo.
pause
endlocal
