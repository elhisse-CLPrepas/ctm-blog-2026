#!/usr/bin/env python3
"""
CTM Blog V6.3 — Générateur meta.json (stable Windows)

Objectif
- Scanner /blog/<slug>/index.html
- Générer ou compléter /blog/<slug>/meta.json
- Déduire date depuis: contenu visible + <title> + <h1>, sinon mtime (index.html)
- Optionnel: créer cover.webp si Pillow dispo et si une image source existe.

Usage (dry run)
  py ./scripts/generate-meta-v6.py --blog-dir "C:/path/to/blog" --base-url "https://clprepas.com/blog"

Usage (write)
  py ./scripts/generate-meta-v6.py --blog-dir "C:/path/to/blog" --base-url "https://clprepas.com/blog" --write
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Any

# Pillow optionnel
try:
    from PIL import Image  # type: ignore
    PIL_OK = True
except Exception:
    PIL_OK = False

EXCLUDE_DIRS = {"assets", "api", "scripts"}

FRENCH_MONTHS = {
    "janvier": 1,
    "février": 2, "fevrier": 2,
    "mars": 3,
    "avril": 4,
    "mai": 5,
    "juin": 6,
    "juillet": 7,
    "août": 8, "aout": 8,
    "septembre": 9,
    "octobre": 10,
    "novembre": 11,
    "décembre": 12, "decembre": 12,
}

DATE_RE = re.compile(
    r'(\d{1,2})\s+(janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre)(?:\s+(\d{4}))?',
    re.IGNORECASE
)

TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)
H1_RE = re.compile(r"<h1[^>]*>(.*?)</h1>", re.IGNORECASE | re.DOTALL)
P_RE = re.compile(r"<p[^>]*>(.*?)</p>", re.IGNORECASE | re.DOTALL)

TAG_RE = re.compile(r"<[^>]+>")

def strip_tags(html: str) -> str:
    s = TAG_RE.sub("", html)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def extract_title(html: str) -> str:
    m = TITLE_RE.search(html)
    if m:
        return strip_tags(m.group(1))
    return ""

def extract_h1(html: str) -> str:
    m = H1_RE.search(html)
    if m:
        return strip_tags(m.group(1))
    return ""

def extract_first_paragraph(html: str) -> str:
    m = P_RE.search(html)
    if m:
        txt = strip_tags(m.group(1))
        return txt
    return ""

def extract_date_from_text(text: str, default_year: int) -> Optional[str]:
    if not text:
        return None
    t = " ".join(text.split())
    m = DATE_RE.search(t)
    if not m:
        return None
    day = int(m.group(1))
    month_name = m.group(2).lower()
    year = int(m.group(3)) if m.group(3) else default_year
    month = FRENCH_MONTHS.get(month_name, None)
    if not month:
        return None
    try:
        d = datetime(year, month, day, tzinfo=timezone.utc)
        return d.strftime("%Y-%m-%d")
    except Exception:
        return None

def file_mtime_iso(path: Path) -> str:
    d = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
    return d.strftime("%Y-%m-%d")

def is_valid_iso_date(s: str) -> bool:
    try:
        datetime.strptime(s, "%Y-%m-%d")
        return True
    except Exception:
        return False

def load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}

def save_json(path: Path, data: dict[str, Any]) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def pick_cover_source(article_dir: Path) -> Optional[Path]:
    # sources candidates
    candidates = [
        article_dir / "assets" / "img" / "og.jpg",
        article_dir / "assets" / "img" / "hero.jpg",
        article_dir / "assets" / "img" / "og.png",
        article_dir / "assets" / "img" / "hero.png",
        article_dir / "og.jpg",
        article_dir / "hero.jpg",
        article_dir / "og.png",
        article_dir / "hero.png",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None

def make_cover_webp(src: Path, dst: Path) -> bool:
    if not PIL_OK:
        return False
    try:
        img = Image.open(src).convert("RGB")
        img = img.resize((1600, 900))
        dst.parent.mkdir(parents=True, exist_ok=True)
        img.save(dst, "WEBP", quality=82, method=6)
        return True
    except Exception:
        return False

def build_meta(slug: str, html: str, index_path: Path, existing: dict[str, Any]) -> dict[str, Any]:
    title_tag = extract_title(html)
    h1 = extract_h1(html)
    p1 = extract_first_paragraph(html)

    # Title
    title = (existing.get("title") or "").strip()
    if not title:
        title = (h1 or title_tag or slug).strip()

    # Excerpt
    excerpt = (existing.get("excerpt") or "").strip()
    if not excerpt:
        excerpt = p1.strip()
        if len(excerpt) > 220:
            excerpt = excerpt[:217].rstrip() + "…"

    # Category / tags / author
    category = (existing.get("category") or "").strip() or "CTM"
    tags = existing.get("tags")
    if not isinstance(tags, list):
        tags = []
    author = (existing.get("author") or "").strip() or "Prof. Abderrahman El Hisse"
    status = (existing.get("status") or "").strip() or "published"

    # Date: prefer existing if valid and not placeholder
    date_iso = (existing.get("date") or "").strip()
    today_iso = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    keep_existing = bool(date_iso) and is_valid_iso_date(date_iso) and date_iso != today_iso

    if not keep_existing:
        default_year = datetime.now(timezone.utc).year
        # Try from visible content + title + h1
        date_from_body = extract_date_from_text(html, default_year)  # content
        date_from_title = extract_date_from_text(title_tag, default_year)
        date_from_h1 = extract_date_from_text(h1, default_year)
        date_iso = date_from_body or date_from_title or date_from_h1

        if not date_iso:
            date_iso = file_mtime_iso(index_path)

    return {
        "title": title,
        "date": date_iso,
        "excerpt": excerpt,
        "category": category,
        "tags": tags,
        "author": author,
        "status": status,
    }

@dataclass
class ItemReport:
    slug: str
    url: str
    meta_action: str
    cover_status: str
    title: str
    date: str
    category: str
    tags: str

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--blog-dir", required=True, help="Path to /blog directory")
    ap.add_argument("--base-url", required=True, help="Base URL, ex: https://clprepas.com/blog")
    ap.add_argument("--write", action="store_true", help="Write meta.json / cover.webp")
    args = ap.parse_args()

    blog_dir = Path(args.blog_dir).resolve()
    base_url = args.base_url.rstrip("/")

    if not blog_dir.exists():
        raise SystemExit(f"Blog dir not found: {blog_dir}")

    reports: list[ItemReport] = []
    count = 0

    for d in sorted([p for p in blog_dir.iterdir() if p.is_dir()]):
        slug = d.name
        if slug in EXCLUDE_DIRS:
            continue

        index_path = d / "index.html"
        if not index_path.exists():
            continue

        html = index_path.read_text(encoding="utf-8", errors="ignore")

        meta_path = d / "meta.json"
        existing = load_json(meta_path)
        new_meta = build_meta(slug, html, index_path, existing)

        meta_action = "created" if not meta_path.exists() else "updated"

        # cover
        cover_dst = d / "cover.webp"
        if cover_dst.exists():
            cover_status = "exists"
        else:
            src = pick_cover_source(d)
            if src and args.write:
                ok = make_cover_webp(src, cover_dst)
                cover_status = "created" if ok else "missing_source"
            else:
                cover_status = "missing_source" if not src else "can_create"

        if args.write:
            save_json(meta_path, new_meta)

        url = f"{base_url}/{slug}/"
        reports.append(ItemReport(
            slug=slug,
            url=url,
            meta_action=meta_action,
            cover_status=cover_status,
            title=new_meta.get("title",""),
            date=new_meta.get("date",""),
            category=new_meta.get("category",""),
            tags=", ".join(new_meta.get("tags", [])) if isinstance(new_meta.get("tags"), list) else ""
        ))
        count += 1

    # Write reports
    generated_at = datetime.now(timezone.utc).isoformat()

    md_lines = []
    md_lines.append("# Rapport meta.json — CTM Blog V6.3")
    md_lines.append("")
    md_lines.append(f"- Généré: {generated_at}")
    md_lines.append(f"- Blog: `{blog_dir}`")
    md_lines.append("")
    md_lines.append("## Résumé")
    md_lines.append(f"- Articles détectés: **{count}**")
    md_lines.append("")
    md_lines.append("## Détails")
    md_lines.append("")

    for r in reports:
        md_lines.append(f"### {r.slug}")
        md_lines.append(f"- URL: {r.url}")
        md_lines.append(f"- meta: {r.meta_action}")
        md_lines.append(f"- cover: {r.cover_status}")
        md_lines.append(f"- title: {r.title}")
        md_lines.append(f"- date: {r.date}")
        md_lines.append(f"- category: {r.category}")
        md_lines.append(f"- tags: {r.tags}")
        md_lines.append("")

    report_md = blog_dir / "scripts" / "meta-report.md"
    report_json = blog_dir / "scripts" / "meta-report.json"
    report_md.parent.mkdir(parents=True, exist_ok=True)
    report_md.write_text("\n".join(md_lines), encoding="utf-8")

    report_payload = {
        "generated_at": generated_at,
        "blog_dir": str(blog_dir),
        "count": count,
        "items": [r.__dict__ for r in reports],
    }
    report_json.write_text(json.dumps(report_payload, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"OK — {count} articles traités.")
    print(f"Rapport: {report_md}")
    if not args.write:
        print("Astuce: relancer avec --write pour écrire les fichiers.")
    else:
        print("Écriture terminée.")
    if not PIL_OK:
        print("Note: Pillow (PIL) absent. Covers non générées.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
