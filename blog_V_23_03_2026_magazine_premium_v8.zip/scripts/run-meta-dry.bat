@echo off
setlocal enabledelayedexpansion

REM ------------------------------------------------------------
REM CTM Blog V6 — TEST (DRY RUN) sans ecriture
REM ------------------------------------------------------------

set "SCRIPT_DIR=%~dp0"
for %%I in ("%SCRIPT_DIR%..") do set "BLOG_DIR=%%~fI"

set "BASE_URL=https://clprepas.com/blog"
set "PY=py"

echo.
echo ============================================
echo CTM Blog V6 - Test meta.json (DRY RUN)
echo Blog dir : "%BLOG_DIR%"
echo Base URL : "%BASE_URL%"
echo ============================================
echo.

%PY% "%SCRIPT_DIR%generate-meta-v6.py" --blog-dir "%BLOG_DIR:\=/%" --base-url "%BASE_URL%"
echo.
echo Termine. Rapport : "%SCRIPT_DIR%meta-report.md"
echo.
pause
endlocal
