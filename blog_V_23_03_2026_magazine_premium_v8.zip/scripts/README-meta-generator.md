# Générateur meta.json + cover.webp — CTM Blog V6.3

Objectif
- Créer `meta.json` pour chaque article
- Créer `cover.webp` (1600x900) si absent
- Compatible avec l’API `api/posts.php` (auto-index)

## Où placer les fichiers
Copiez:
- `generate-meta-v6.py` dans `/blog/scripts/`
- `prompt-ia-meta.txt` dans `/blog/scripts/` (optionnel)

## Exécution (Windows PowerShell)
Dry-run (ne modifie rien):
python .\scripts\generate-meta-v6.py --blog-dir "C:\xampp\htdocs\blog" --base-url "https://clprepas.com/blog"

Écriture réelle:
python .\scripts\generate-meta-v6.py --blog-dir "C:\xampp\htdocs\blog" --base-url "https://clprepas.com/blog" --write

## Sorties
- `/blog/<slug>/meta.json` (créé ou mis à jour)
- `/blog/<slug>/cover.webp` (créé si possible depuis `assets/img/og.jpg` ou `assets/img/hero.jpg`)
- `/blog/scripts/meta-report.json`
- `/blog/scripts/meta-report.md`

## Notes
- La date est extraite si possible depuis le titre ou le H1 (ex: "27 février 2026").
- Sinon, date du jour.
- Les tags sont déduits du slug et du contenu, puis dédoublonnés.
