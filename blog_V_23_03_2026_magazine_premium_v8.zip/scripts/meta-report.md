# Rapport meta.json — CTM Blog V6.3

- Généré: 2026-03-12T21:38:26.575320+00:00
- Blog: `C:\Users\Utilisateur\Desktop\0001Mars 2026\CTM_IA_2026\blog`

## Résumé
- Articles détectés: **18**

## Détails

### avoir-raison
- URL: https://clprepas.com/blog/avoir-raison/
- meta: updated
- cover: missing_source
- title: Avoir raison (18 février) | CTM | Booster nos capacités
- date: 2026-02-18
- category: CTM
- tags: CTM

### booster-capacité-ia
- URL: https://clprepas.com/blog/booster-capacité-ia/
- meta: updated
- cover: missing_source
- title: Sécuriser vos connexions GitHub pour l’IA
- date: 2026-02-17
- category: CTM
- tags: CTM, IA

### controle-lacher-prise
- URL: https://clprepas.com/blog/controle-lacher-prise/
- meta: updated
- cover: missing_source
- title: Lâcher prise : l'illusion du contrôle et le retour à soi
- date: 2026-02-23
- category: Mindset
- tags: Mindset

### ctm-alliance-ia
- URL: https://clprepas.com/blog/ctm-alliance-ia/
- meta: created
- cover: created
- title: ALLIANCE entre sagesse des seniors, l’IA, l’autonomie et l’allostasie
- date: 2026-03-12
- category: CTM
- tags: 

### ctm-alliance-soi
- URL: https://clprepas.com/blog/ctm-alliance-soi/
- meta: updated
- cover: exists
- title: ALLIANCE AVEC SOI
- date: 2026-03-11
- category: CTM
- tags: 

### ctm-cerveau-predictif
- URL: https://clprepas.com/blog/ctm-cerveau-predictif/
- meta: updated
- cover: exists
- title: Cerveau prédictif dynamique · 25 février 2026 · CTM
- date: 2026-02-25
- category: CTM
- tags: CTM, IA, Cerveau

### ctm-enregistrer-obs
- URL: https://clprepas.com/blog/ctm-enregistrer-obs/
- meta: updated
- cover: exists
- title: Enregistrer des cours et tutoriels avec OBS Studio · CTM
- date: 2026-02-26
- category: CTM
- tags: CTM, OBS

### ctm-formation-ia50
- URL: https://clprepas.com/blog/ctm-formation-ia50/
- meta: updated
- cover: exists
- title: Landing Pages Easy — Formation IA 50+ · 27 février 2026 · CTM
- date: 2026-02-27
- category: CTM
- tags: CTM, IA, Landing Pages

### ctm-notre-chemin
- URL: https://clprepas.com/blog/ctm-notre-chemin/
- meta: updated
- cover: exists
- title: Notre chemin · 28 février 2026 · CTM
- date: 2026-02-28
- category: CTM
- tags: CTM, IA

### ctm-veille-ia
- URL: https://clprepas.com/blog/ctm-veille-ia/
- meta: updated
- cover: exists
- title: Guide personnel de veille IA 2026
- date: 2026-03-09
- category: IA & Outils
- tags: IA, Veille, ChatGPT, Agents, CTM, Productivité

### ctm-webmcp-ia
- URL: https://clprepas.com/blog/ctm-webmcp-ia/
- meta: updated
- cover: exists
- title: WebMCP & Web Agentique · 27 février 2026 · CTM
- date: 2026-02-27
- category: CTM
- tags: CTM, IA

### deepseek-article
- URL: https://clprepas.com/blog/deepseek-article/
- meta: updated
- cover: missing_source
- title: DeepSeek – L'IA qui démultiplie vos capacités
- date: 2026-02-22
- category: CTM
- tags: CTM, IA

### detachement
- URL: https://clprepas.com/blog/detachement/
- meta: updated
- cover: missing_source
- title: Détachement · Lâcher prise dans l’amour et les relations · CTM
- date: 2026-02-16
- category: CTM
- tags: CTM, Mindset

### generation-z
- URL: https://clprepas.com/blog/generation-z/
- meta: updated
- cover: missing_source
- title: Gen Z : qui sont-ils ? - Comprendre la génération Z
- date: 2026-02-10
- category: Général
- tags: 

### manus
- URL: https://clprepas.com/blog/manus/
- meta: updated
- cover: missing_source
- title: Manus · Guide + Flashcards · CTM
- date: 2026-02-16
- category: CTM
- tags: CTM

### notre-chemin
- URL: https://clprepas.com/blog/notre-chemin/
- meta: updated
- cover: missing_source
- title: Notre chemin · 19 février · CTM
- date: 2026-02-19
- category: CTM
- tags: CTM

### savoir-prendre-du-recul
- URL: https://clprepas.com/blog/savoir-prendre-du-recul/
- meta: updated
- cover: exists
- title: Savoir prendre du recul · CTM
- date: 2026-02-23
- category: CTM
- tags: CTM, IA

### supra-transformation
- URL: https://clprepas.com/blog/supra-transformation/
- meta: updated
- cover: missing_source
- title: Supra-transformation - CTM
- date: 2026-02-21
- category: CTM
- tags: CTM, IA
