# Refonte blog CTM — 23-03-2026

## Modifications principales
- nouvelle page d’accueil plus premium
- nouvelles pages `categories/` et `archives/`
- taxonomie éditoriale resserrée
- fallback `data/posts-fallback.json` pour prévisualiser le blog même sans dossiers d’articles dans le ZIP
- API `api/posts.php` améliorée pour regrouper les articles dans des catégories plus utiles
- nouveaux visuels de fond par défaut

## Déploiement
1. sauvegarder le dossier `/blog/` actuel
2. remplacer les fichiers par le contenu du ZIP
3. vérifier `/blog/`, `/blog/categories/` et `/blog/archives/`
4. tester `api/posts.php`
5. si les dossiers d’articles existent sur le serveur, l’API prendra automatiquement le relais du fallback
