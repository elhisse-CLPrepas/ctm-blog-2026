<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$blogRoot = realpath(__DIR__ . '/..');
if (!$blogRoot) {
  echo json_encode([]);
  exit;
}

$exclude = ['assets', 'api', 'scripts', 'data', 'categories', 'archives'];
$defaultCover = '/blog/assets/img/cover-default.webp';
$items = [];
$dirs = glob($blogRoot . '/*', GLOB_ONLYDIR);
if (!$dirs) {
  echo json_encode([]);
  exit;
}

function contains_any($text, $keywords) {
  foreach ($keywords as $kw) {
    if (mb_strpos($text, $kw) !== false) return true;
  }
  return false;
}

function normalize_category($title, $excerpt, $originalCategory, $tags) {
  $text = mb_strtolower(trim($title . ' ' . $excerpt . ' ' . $originalCategory . ' ' . implode(' ', $tags)), 'UTF-8');

  if (contains_any($text, ['chatgpt','agent','agentique','webmcp','ia','deepseek','github','obs','outil','outils','veille','api','flashcards','landing page','landing pages','meta','automation','automatisation','studio'])) {
    return 'IA & Outils';
  }

  if (contains_any($text, ['confiance','lâcher prise','lacher prise','détachement','detachement','recul','soi','allostasie','transformation','predictif','prédictif','mindset','émotion','emotion','cerveau'])) {
    return 'Mindset & Transformation';
  }

  if (contains_any($text, ['cours','tutoriel','guide','formation','enseigner','apprendre','pédagog','pedagog','méthode','methode'])) {
    return 'Pédagogie & Transmission';
  }

  if (contains_any($text, ['club','ctm','tiriens','alliance','notre chemin','communauté','communaute','seniors'])) {
    return 'CTM & Communauté';
  }

  $map = [
    'mindset' => 'Mindset & Transformation',
    'ia & outils' => 'IA & Outils',
    'ctm' => 'CTM & Communauté',
    'général' => 'Général',
    'general' => 'Général',
  ];

  $key = mb_strtolower(trim((string)$originalCategory), 'UTF-8');
  return $map[$key] ?? 'Général';
}

foreach ($dirs as $dir) {
  $slug = basename($dir);
  if (in_array($slug, $exclude, true)) continue;

  $indexPath = $dir . '/index.html';
  $metaPath  = $dir . '/meta.json';
  if (!file_exists($indexPath) || !file_exists($metaPath)) continue;

  $metaRaw = file_get_contents($metaPath);
  $meta = json_decode($metaRaw, true);
  if (!is_array($meta)) continue;

  $title    = trim((string)($meta['title'] ?? $slug));
  $dateISO  = trim((string)($meta['date'] ?? '1970-01-01'));
  $excerpt  = trim((string)($meta['excerpt'] ?? ''));
  $tags     = is_array($meta['tags'] ?? null) ? $meta['tags'] : [];
  $author   = trim((string)($meta['author'] ?? ''));
  $originalCategory = trim((string)($meta['category'] ?? ''));
  if ($originalCategory === '' && count($tags) > 0) $originalCategory = (string)$tags[0];
  if ($originalCategory === '') $originalCategory = 'Général';
  $category = normalize_category($title, $excerpt, $originalCategory, $tags);

  $coverAbs  = $dir . '/cover.webp';
  $coverUrl  = file_exists($coverAbs) ? "/blog/$slug/cover.webp" : $defaultCover;

  $items[] = [
    'id' => $slug,
    'slug' => $slug,
    'url' => "/blog/$slug/",
    'title' => $title,
    'dateISO' => $dateISO,
    'category' => $category,
    'originalCategory' => $originalCategory,
    'description' => $excerpt,
    'cover' => $coverUrl,
    'tags' => $tags,
    'author' => $author,
  ];
}

usort($items, fn($a, $b) => strcmp($b['dateISO'], $a['dateISO']));
echo json_encode($items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
