# Refonte blog CTM v8 — version magazine premium

## Ce qui change
- identité visuelle plus premium avec palette CTM bleu nuit, doré et papier clair
- typographie éditoriale avec titres serif et texte sans-serif
- page d’accueil transformée en vraie page magazine
- bloc “Édition en une” pour mettre l’article le plus récent au centre
- rail éditorial secondaire pour les autres publications récentes
- cartes articles plus nobles et plus lisibles
- catégories présentées comme univers éditoriaux
- pages catégories et archives harmonisées au même niveau de finition
- descriptions automatiques plus parlantes si les articles n’ont pas d’extrait

## Fichiers nouveaux
- assets/blog-v8.css
- assets/blog-v8.js

## Fichiers mis à jour
- index.html
- categories/index.html
- archives/index.html

## Déploiement
1. sauvegarder l’ancienne version du dossier /public_html/blog/
2. téléverser et décompresser le ZIP
3. vérifier /blog/ puis /blog/categories/ puis /blog/archives/
4. si les vrais dossiers d’articles existent, api/posts.php continue de les lire automatiquement
5. si le ZIP est isolé sans dossiers d’articles, le fallback data/posts-fallback.json reste actif

## Observation
Cette version renforce surtout l’image éditoriale.
Elle ne modifie pas la logique métier du blog.
Elle améliore la perception de qualité, la hiérarchie et la lisibilité.
