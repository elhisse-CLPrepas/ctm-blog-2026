
(() => {
  const PAGE_SIZE = 9;
  const NEW_DAYS = 14;
  const body = document.body;
  const pageKind = body?.dataset?.page || 'home';
  const base = body?.dataset?.base || '';
  const API_URL = body?.dataset?.api || `${base}api/posts.php`;
  const FALLBACK_URL = body?.dataset?.fallback || `${base}data/posts-fallback.json`;

  const CATEGORY_INFO = {
    'IA & Outils': 'Guides, automatisation, plateformes, outils et usages IA.',
    'Mindset & Transformation': 'Recul, confiance, allostasie, clarté mentale et évolution intérieure.',
    'Pédagogie & Transmission': 'Formation, méthode, explication, cours et accompagnement structuré.',
    'CTM & Communauté': 'Vie éditoriale CTM, vision, collectif, parcours et dynamique communautaire.',
    'Général': 'Articles transversaux qui ne relèvent pas d’une seule famille dominante.'
  };

  const ORDER = ['IA & Outils', 'Mindset & Transformation', 'Pédagogie & Transmission', 'CTM & Communauté', 'Général'];
  const MONTH_FR = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];

  const el = {
    grid: document.getElementById('articlesGrid'),
    empty: document.getElementById('emptyState'),
    pager: document.getElementById('pager'),
    chips: document.getElementById('chipsWrap'),
    search: document.getElementById('searchInput'),
    sortBtn: document.getElementById('sortBtn'),
    results: document.getElementById('resultsPill'),
    reset: document.getElementById('resetBtn'),
    kpiTotal: document.getElementById('kpiTotal'),
    kpiCats: document.getElementById('kpiCats'),
    kpiNew: document.getElementById('kpiNew'),
    kpiMonth: document.getElementById('kpiMonth'),
    banner: document.getElementById('loadBanner'),
    bannerMsg: document.getElementById('loadBannerMsg'),
    bannerLink: document.getElementById('loadBannerLink'),
    featured: document.getElementById('featuredMount'),
    categoryDeck: document.getElementById('categoryDeck'),
    archiveMount: document.getElementById('archiveMount'),
    issueLead: document.getElementById('issueLead'),
    issueRail: document.getElementById('issueRail')
  };

  const state = {
    all: [],
    q: '',
    category: 'Toutes',
    sort: 'desc',
    page: 1
  };

  init();

  async function init(){
    showBanner('Chargement du blog…', 'neutral');
    let items = [];
    let source = 'api';
    try {
      const apiData = await fetchJSON(API_URL);
      if (Array.isArray(apiData) && apiData.length > 0) {
        items = apiData;
        source = 'api';
      } else {
        items = await fetchJSON(FALLBACK_URL);
        source = 'fallback';
      }
    } catch (err) {
      try {
        items = await fetchJSON(FALLBACK_URL);
        source = 'fallback';
      } catch {
        items = [];
      }
    }

    state.all = normalize(items);
    mountKPIs(state.all);

    if (source === 'api') {
      hideBanner();
    } else if (state.all.length) {
      showBanner('Mode prévisualisation : données de secours chargées car les dossiers d’articles ne sont pas présents dans ce ZIP.', 'neutral');
      if (el.bannerLink) el.bannerLink.href = FALLBACK_URL;
    } else {
      showBanner('Aucune donnée détectée. Vérifiez api/posts.php ou data/posts-fallback.json.', 'error');
    }

    bind();
    if (pageKind === 'archives') renderArchivesPage();
    else if (pageKind === 'categories') renderCategoriesPage();
    else renderHomePage();
  }

  async function fetchJSON(url){
    const res = await fetch(url, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  }

  function bind(){
    if (el.search) {
      el.search.addEventListener('input', () => {
        state.q = el.search.value.trim();
        state.page = 1;
        renderFilteredGrid();
      });
    }

    if (el.sortBtn) {
      el.sortBtn.addEventListener('click', () => {
        state.sort = state.sort === 'desc' ? 'asc' : 'desc';
        el.sortBtn.textContent = state.sort === 'desc' ? 'Trier: récent → ancien' : 'Trier: ancien → récent';
        state.page = 1;
        if (pageKind === 'archives') renderArchivesPage();
        else renderFilteredGrid();
      });
    }

    if (el.reset) {
      el.reset.addEventListener('click', () => {
        state.q = '';
        state.category = 'Toutes';
        state.sort = 'desc';
        state.page = 1;
        if (el.search) el.search.value = '';
        if (el.sortBtn) el.sortBtn.textContent = 'Trier: récent → ancien';
        setChipPressed('Toutes');
        if (pageKind === 'archives') renderArchivesPage();
        else if (pageKind === 'categories') {
          history.replaceState({}, '', './');
          renderCategoriesPage();
        } else {
          renderHomePage();
        }
      });
    }
  }

  function normalize(items){
    return (items || []).map((it) => {
      const tags = Array.isArray(it.tags) ? it.tags.filter(Boolean) : typeof it.tags === 'string' ? it.tags.split(',').map(x => x.trim()).filter(Boolean) : [];
      const title = it.title || '';
      const description = it.description || it.excerpt || '';
      const originalCategory = it.originalCategory || it.category || '';
      const category = mapCategory({ title, description, originalCategory, tags, category: it.category || '' });
      const dateISO = sanitizeISO(it.dateISO || it.date || '1970-01-01');
      const teaser = deriveDescription({title, description, category, tags});
      return {
        id: it.id || it.slug || it.url || title,
        slug: it.slug || '',
        title,
        url: it.url || '#',
        cover: resolveURL(it.cover),
        category,
        originalCategory,
        tags,
        description: teaser,
        dateISO,
        dateLabel: formatDateFR(dateISO),
        isNew: daysOld(dateISO) <= NEW_DAYS
      };
    }).sort((a,b) => b.dateISO.localeCompare(a.dateISO));
  }

  function mapCategory(item){
    const hay = `${item.title} ${item.description} ${item.originalCategory} ${(item.tags || []).join(' ')} ${item.category || ''}`.toLowerCase();
    const has = (...arr) => arr.some((w) => hay.includes(w));
    if (has('chatgpt','agent','agentique','webmcp','ia','deepseek','github','obs','outil','outils','veille','api','flashcards','landing page','landing pages','meta','automation','automatisation','studio')) return 'IA & Outils';
    if (has('confiance','lâcher prise','lacher prise','détachement','detachement','recul','soi','allostasie','transformation','predictif','prédictif','mindset','émotion','emotion','cerveau')) return 'Mindset & Transformation';
    if (has('cours','tutoriel','guide','formation','enseigner','apprendre','pédagog','pedagog','méthode','methode')) return 'Pédagogie & Transmission';
    if (has('club','ctm','tiriens','alliance','notre chemin','communauté','communaute','seniors')) return 'CTM & Communauté';
    const mapping = {
      'mindset': 'Mindset & Transformation',
      'ia & outils': 'IA & Outils',
      'ctm': 'CTM & Communauté',
      'général': 'Général',
      'general': 'Général'
    };
    return mapping[(item.originalCategory || '').trim().toLowerCase()] || 'Général';
  }

  function deriveDescription(item){
    const clean = (item.description || '').trim().replace(/\s+/g, ' ');
    if (clean) return clean.length > 170 ? `${clean.slice(0, 167)}…` : clean;
    const title = item.title.replace(/\s+\|\s+.*$/, '').trim();
    const variants = {
      'IA & Outils': `Analyse CTM autour de “${title}” avec un angle d’usage, de méthode et de mise en pratique.`,
      'Mindset & Transformation': `Réflexion CTM sur “${title}” pour clarifier l’élan intérieur, le recul et la transformation.`,
      'Pédagogie & Transmission': `Lecture pédagogique CTM de “${title}” avec une logique de transmission, d’apprentissage et de méthode.`,
      'CTM & Communauté': `Article CTM centré sur “${title}” pour nourrir la vision, le lien collectif et la dynamique de communauté.`,
      'Général': `Publication éditoriale CTM autour de “${title}” avec une approche structurée et accessible.`
    };
    return variants[item.category] || variants['Général'];
  }

  function resolveURL(url){
    if (!url) return `${base}assets/img/cover-default.webp`;
    if (/^(https?:)?\/\//i.test(url) || url.startsWith('/')) return url;
    return `${base}${url.replace(/^\.\//, '')}`;
  }

  function sanitizeISO(iso){
    return /^\d{4}-\d{2}-\d{2}$/.test(String(iso)) ? iso : '1970-01-01';
  }

  function mountKPIs(items){
    const newestMonth = items.length ? items[0].dateISO.slice(0,7) : '';
    if (el.kpiTotal) el.kpiTotal.textContent = String(items.length);
    if (el.kpiCats) el.kpiCats.textContent = String(new Set(items.map(item => item.category)).size);
    if (el.kpiNew) el.kpiNew.textContent = String(items.filter(item => item.isNew).length);
    if (el.kpiMonth) el.kpiMonth.textContent = newestMonth ? monthTitle(newestMonth) : '—';
  }

  function renderHomePage(){
    mountChips(state.all);
    renderIssue(state.all);
    renderCategoryDeck(state.all, false);
    renderFeatured(state.all.slice(1, 4));
    renderFilteredGrid();
  }

  function renderCategoriesPage(){
    const params = new URLSearchParams(window.location.search);
    const queryCategory = params.get('cat');
    if (queryCategory && ORDER.includes(queryCategory)) {
      state.category = queryCategory;
      setChipPressed(queryCategory);
    }
    mountChips(state.all);
    renderCategoryDeck(state.all, true);
    setChipPressed(state.category);
    renderFilteredGrid();
  }

  function renderArchivesPage(){
    renderFeatured(applySort(state.all).slice(0, 3));
    renderArchives(applySort(state.all));
    if (el.results) el.results.textContent = `${state.all.length} ${state.all.length > 1 ? 'articles' : 'article'}`;
  }

  function renderIssue(items){
    const sorted = applySort(items);
    const lead = sorted[0];
    const rail = sorted.slice(1, 4);
    if (el.issueLead) {
      if (!lead) {
        el.issueLead.innerHTML = '<div class="editorial-note card-surface"><div class="micro-kicker">ÉDITION EN UNE</div><h3 class="editorial-heading">Aucun article disponible</h3><p>Ajoutez vos articles pour activer la une du blog CTM.</p></div>';
      } else {
        el.issueLead.innerHTML = issueLeadHTML(lead);
      }
    }
    if (el.issueRail) {
      el.issueRail.innerHTML = rail.length ? rail.map(issueMiniHTML).join('') : '';
    }
  }

  function renderCategoryDeck(items, withLinks){
    if (!el.categoryDeck) return;
    const counts = categoryCounts(items);
    const html = ORDER.filter(cat => counts[cat]).map(cat => {
      const href = withLinks ? `?cat=${encodeURIComponent(cat)}#liste` : `categories/?cat=${encodeURIComponent(cat)}#liste`;
      return `
        <a class="category-card" href="${href}">
          <div class="category-top">
            <div>
              <div class="micro-kicker">univers</div>
              <div class="category-name">${escapeHtml(cat)}</div>
              <div class="category-desc">${escapeHtml(CATEGORY_INFO[cat] || '')}</div>
            </div>
            <div class="category-count">${counts[cat]}</div>
          </div>
        </a>
      `;
    }).join('');
    el.categoryDeck.innerHTML = html || '<div class="empty card-surface">Aucune catégorie disponible.</div>';
  }

  function renderFeatured(items){
    if (!el.featured) return;
    el.featured.innerHTML = items.map(cardHTML).join('');
  }

  function renderFilteredGrid(){
    if (!el.grid) return;
    const filtered = applyFilters(state.all);
    const sorted = applySort(filtered);
    const total = sorted.length;
    const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    state.page = Math.min(Math.max(state.page, 1), pages);
    const start = (state.page - 1) * PAGE_SIZE;
    const pageItems = sorted.slice(start, start + PAGE_SIZE);
    if (el.results) el.results.textContent = `${total} ${total > 1 ? 'résultats' : 'résultat'}`;
    if (el.empty) el.empty.hidden = total !== 0;
    el.grid.innerHTML = pageItems.map(cardHTML).join('');
    if (el.pager) el.pager.innerHTML = pagerHTML(state.page, pages);
    bindPager();
  }

  function renderArchives(items){
    if (!el.archiveMount) return;
    const groups = new Map();
    for (const item of items) {
      const [year, month] = item.dateISO.split('-').map(Number);
      const key = `${year}-${String(month).padStart(2,'0')}`;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(item);
    }
    const html = [...groups.entries()].map(([key, list]) => {
      const title = monthTitle(key);
      const listHTML = list.map(item => `
        <a class="archive-link" href="${item.url}">
          <div class="archive-date">${escapeHtml(item.dateLabel)}</div>
          <div class="archive-text">
            <strong>${escapeHtml(item.title)}</strong>
            <span>${escapeHtml(item.category)}</span>
          </div>
        </a>
      `).join('');
      return `
        <section class="archive-block card-surface">
          <div class="archive-title">
            <h3>${escapeHtml(title)}</h3>
            <div class="archive-count">${list.length}</div>
          </div>
          <div class="archive-list">${listHTML}</div>
        </section>
      `;
    }).join('');
    el.archiveMount.innerHTML = html || '<div class="empty card-surface">Aucune archive disponible.</div>';
  }

  function mountChips(items){
    if (!el.chips) return;
    const counts = categoryCounts(items);
    const list = ['Toutes', ...ORDER.filter(cat => counts[cat])];
    el.chips.innerHTML = list.map(cat => {
      const countText = cat === 'Toutes' ? items.length : counts[cat] || 0;
      return `<button class="chip" type="button" data-cat="${escAttr(cat)}" aria-pressed="${cat === state.category}">${escapeHtml(cat)} · ${countText}</button>`;
    }).join('');
    el.chips.querySelectorAll('.chip').forEach((btn) => {
      btn.addEventListener('click', () => {
        state.category = btn.getAttribute('data-cat') || 'Toutes';
        state.page = 1;
        setChipPressed(state.category);
        if (pageKind === 'categories') {
          if (state.category === 'Toutes') history.replaceState({}, '', './#liste');
          else history.replaceState({}, '', `?cat=${encodeURIComponent(state.category)}#liste`);
        }
        renderFilteredGrid();
      });
    });
  }

  function setChipPressed(cat){
    if (!el.chips) return;
    el.chips.querySelectorAll('.chip').forEach((btn) => {
      btn.setAttribute('aria-pressed', String((btn.getAttribute('data-cat') || '') === cat));
    });
  }

  function applyFilters(items){
    const q = state.q.toLowerCase();
    return items.filter((item) => {
      if (state.category !== 'Toutes' && item.category !== state.category) return false;
      if (!q) return true;
      const hay = [item.title, item.description, item.category, item.originalCategory, ...(item.tags || [])].join(' ').toLowerCase();
      return hay.includes(q);
    });
  }

  function applySort(items){
    return [...items].sort((a,b) => state.sort === 'desc' ? b.dateISO.localeCompare(a.dateISO) : a.dateISO.localeCompare(b.dateISO));
  }

  function categoryCounts(items){
    const counts = {};
    for (const item of items) counts[item.category] = (counts[item.category] || 0) + 1;
    return counts;
  }

  function issueLeadHTML(item){
    const metaOriginal = item.originalCategory && item.originalCategory !== item.category ? ` · ${escapeHtml(item.originalCategory)}` : '';
    return `
      <a class="issue-lead" href="${item.url}" style="--issue-cover:url('${escAttr(item.cover)}')">
        <div class="issue-lead-inner">
          <span class="issue-label">Édition en une</span>
          <h2 class="issue-lead-title">${escapeHtml(item.title)}</h2>
          <p class="issue-lead-desc">${escapeHtml(item.description)}</p>
          <div class="issue-lead-meta">
            <span>${escapeHtml(item.dateLabel)}</span>
            <span>${escapeHtml(item.category)}${metaOriginal}</span>
            <span>Prof Abderrahman El Hisse</span>
          </div>
        </div>
      </a>
    `;
  }

  function issueMiniHTML(item){
    return `
      <a class="issue-mini card-surface" href="${item.url}">
        <div class="issue-mini-cover" style="background-image:url('${escAttr(item.cover)}')"></div>
        <div>
          <div class="issue-mini-meta">${escapeHtml(item.category)} · ${escapeHtml(item.dateLabel)}</div>
          <div class="issue-mini-title">${escapeHtml(item.title)}</div>
          <p>${escapeHtml(item.description)}</p>
        </div>
      </a>
    `;
  }

  function cardHTML(item){
    const tagBadges = (item.tags || []).slice(0, 2).map(tag => `<span class="badge">${escapeHtml(tag)}</span>`).join('');
    return `
      <a class="card-item" href="${item.url}">
        <div class="card-media" style="background-image:url('${escAttr(item.cover)}')"></div>
        <div class="card-body">
          <div class="badges">
            <span class="badge">${escapeHtml(item.category)}</span>
            ${item.isNew ? '<span class="badge badge-new">Nouveau</span>' : ''}
            ${tagBadges}
          </div>
          <div class="card-meta">
            <span>${escapeHtml(item.dateLabel)}</span>
            ${item.originalCategory && item.originalCategory !== item.category ? `<span>· ${escapeHtml(item.originalCategory)}</span>` : ''}
          </div>
          <h3 class="card-title">${escapeHtml(item.title)}</h3>
          <p class="card-desc">${escapeHtml(item.description)}</p>
          <span class="card-cta">Lire l’article →</span>
        </div>
      </a>
    `;
  }

  function pagerHTML(page, pages){
    if (pages <= 1) return '';
    const out = [];
    const btn = (p, label, current = false) => `<button class="pagebtn" type="button" data-page="${p}" ${current ? 'aria-current="page"' : ''}>${label}</button>`;
    out.push(btn(Math.max(1, page - 1), '←'));
    const first = Math.max(1, page - 2);
    const last = Math.min(pages, first + 4);
    if (first > 1) out.push(btn(1, '1', page === 1));
    if (first > 2) out.push('<span class="meta-line">…</span>');
    for (let p = first; p <= last; p += 1) out.push(btn(p, String(p), p === page));
    if (last < pages - 1) out.push('<span class="meta-line">…</span>');
    if (last < pages) out.push(btn(pages, String(pages), page === pages));
    out.push(btn(Math.min(pages, page + 1), '→'));
    return out.join('');
  }

  function bindPager(){
    if (!el.pager) return;
    el.pager.querySelectorAll('button[data-page]').forEach((button) => {
      button.addEventListener('click', () => {
        const next = Number(button.getAttribute('data-page'));
        if (!Number.isFinite(next)) return;
        state.page = next;
        renderFilteredGrid();
        const topAnchor = document.getElementById('articles') || document.getElementById('liste');
        if (topAnchor) window.scrollTo({ top: topAnchor.offsetTop - 84, behavior: 'smooth' });
      });
    });
  }

  function formatDateFR(iso){
    const d = new Date(`${iso}T00:00:00`);
    if (Number.isNaN(d.getTime())) return iso;
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });
  }

  function daysOld(iso){
    const d = new Date(`${iso}T00:00:00`);
    if (Number.isNaN(d.getTime())) return 9999;
    const now = new Date();
    return Math.floor((now.getTime() - d.getTime()) / 86400000);
  }

  function monthTitle(key){
    const [year, month] = key.split('-').map(Number);
    return `${capitalize(MONTH_FR[(month || 1) - 1] || '')} ${year || ''}`.trim();
  }

  function showBanner(msg, type){
    if (!el.banner) return;
    el.banner.hidden = false;
    el.bannerMsg.textContent = msg;
    el.banner.dataset.type = type || 'neutral';
  }

  function hideBanner(){
    if (!el.banner) return;
    el.banner.hidden = true;
  }

  function escapeHtml(str){
    return String(str).replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m]));
  }

  function escAttr(str){ return escapeHtml(str).replace(/"/g, '&quot;'); }
  function capitalize(str){ return str ? str.charAt(0).toUpperCase() + str.slice(1) : ''; }
})();
