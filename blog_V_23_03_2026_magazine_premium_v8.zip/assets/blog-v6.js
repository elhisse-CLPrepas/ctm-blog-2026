/* Blog CTM V6 — UI avancée + API auto-index (posts.php) */
(() => {
  const API_URL = "api/posts.php";
  const PAGE_SIZE = 9;
  const NEW_DAYS = 10;

  const el = {
    grid: document.getElementById("articlesGrid"),
    empty: document.getElementById("emptyState"),
    pager: document.getElementById("pager"),
    chips: document.getElementById("chipsWrap"),
    search: document.getElementById("searchInput"),
    sortBtn: document.getElementById("sortBtn"),
    results: document.getElementById("resultsPill"),
    reset: document.getElementById("resetBtn"),
    kpiTotal: document.getElementById("kpiTotal"),
    kpiCats: document.getElementById("kpiCats"),
    kpiNew: document.getElementById("kpiNew"),
    banner: document.getElementById("loadBanner"),
    bannerMsg: document.getElementById("loadBannerMsg"),
    bannerLink: document.getElementById("loadBannerLink"),
  };

  const state = {
    all: [],
    q: "",
    category: "Toutes",
    sort: "desc", // desc = récent -> ancien
    page: 1,
  };

  init();

  async function init() {
    showBanner("Chargement via l’API PHP…", "neutral");

    let data = [];
    try {
      const res = await fetch(API_URL, { cache: "no-store" });
      data = await res.json();
      if (!Array.isArray(data)) throw new Error("Bad JSON");
      hideBanner();
    } catch (e) {
      showBanner("Impossible de charger l’API. Vérifiez /blog/api/posts.php.", "error");
      data = [];
    }

    state.all = normalize(data);
    mountChips(state.all);
    mountKPIs(state.all);

    bind();
    render();
  }

  function normalize(items) {
    return items.map(it => {
      const dateISO = it.dateISO || it.date || "1970-01-01";
      return {
        id: it.id || it.slug || it.url,
        title: it.title || "",
        url: it.url || "#",
        cover: it.cover || "/blog/assets/img/cover-default.webp",
        category: it.category || (Array.isArray(it.tags) && it.tags[0]) || "Général",
        tags: Array.isArray(it.tags) ? it.tags : [],
        description: it.description || it.excerpt || "",
        dateISO,
        dateLabel: formatDateFR(dateISO),
      };
    });
  }

  function bind() {
    el.search?.addEventListener("input", () => {
      state.q = el.search.value.trim();
      state.page = 1;
      render();
    });

    el.sortBtn?.addEventListener("click", () => {
      state.sort = state.sort === "desc" ? "asc" : "desc";
      el.sortBtn.textContent = state.sort === "desc"
        ? "Trier: récent → ancien"
        : "Trier: ancien → récent";
      state.page = 1;
      render();
    });

    el.reset?.addEventListener("click", () => {
      state.q = "";
      state.category = "Toutes";
      state.sort = "desc";
      state.page = 1;
      if (el.search) el.search.value = "";
      if (el.sortBtn) el.sortBtn.textContent = "Trier: récent → ancien";
      setChipPressed("Toutes");
      render();
      window.location.hash = "#liste";
    });
  }

  function mountChips(items) {
    const cats = Array.from(new Set(items.map(x => x.category))).sort((a,b) => a.localeCompare(b, "fr"));
    const list = ["Toutes", ...cats];

    el.chips.innerHTML = list.map(c => `
      <button class="chip" type="button" data-cat="${escAttr(c)}" aria-pressed="${c === "Toutes"}">
        ${escapeHtml(c)}
      </button>
    `).join("");

    el.chips.querySelectorAll(".chip").forEach(btn => {
      btn.addEventListener("click", () => {
        state.category = btn.getAttribute("data-cat") || "Toutes";
        state.page = 1;
        setChipPressed(state.category);
        render();
      });
    });
  }

  function setChipPressed(cat) {
    el.chips.querySelectorAll(".chip").forEach(btn => {
      const isOn = (btn.getAttribute("data-cat") || "") === cat;
      btn.setAttribute("aria-pressed", isOn ? "true" : "false");
    });
  }

  function mountKPIs(items) {
    const total = items.length;
    const cats = new Set(items.map(x => x.category)).size;
    const now = new Date();
    const fresh = items.filter(x => daysBetweenISO(x.dateISO, now) <= NEW_DAYS).length;

    el.kpiTotal.textContent = String(total);
    el.kpiCats.textContent = String(cats);
    el.kpiNew.textContent = String(fresh);
  }

  function render() {
    const filtered = applyFilters(state.all);
    const sorted = applySort(filtered);

    const total = sorted.length;
    const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    state.page = clamp(state.page, 1, pages);

    const start = (state.page - 1) * PAGE_SIZE;
    const pageItems = sorted.slice(start, start + PAGE_SIZE);

    // Results pill
    const label = total <= 1 ? "résultat" : "résultats";
    el.results.textContent = `${total} ${label}`;

    // Empty state
    el.empty.hidden = total !== 0;

    // Grid
    el.grid.innerHTML = pageItems.map(cardHTML).join("");

    // Pager
    el.pager.innerHTML = pagerHTML(state.page, pages);
    el.pager.querySelectorAll("button[data-page]").forEach(b => {
      b.addEventListener("click", () => {
        const p = Number(b.getAttribute("data-page"));
        if (!Number.isFinite(p)) return;
        state.page = p;
        render();
        window.scrollTo({ top: document.getElementById("liste").offsetTop - 70, behavior: "smooth" });
      });
    });
  }

  function applyFilters(items) {
    const q = state.q.toLowerCase();
    return items.filter(x => {
      if (state.category !== "Toutes" && x.category !== state.category) return false;
      if (!q) return true;

      const hay = [
        x.title,
        x.description,
        x.category,
        ...(x.tags || [])
      ].join(" ").toLowerCase();

      return hay.includes(q);
    });
  }

  function applySort(items) {
    return [...items].sort((a,b) => {
      const cmp = (a.dateISO || "").localeCompare(b.dateISO || "");
      return state.sort === "desc" ? -cmp : cmp;
    });
  }

  function cardHTML(p) {
    return `
      <a class="card" href="${p.url}">
        <div class="thumb" style="background-image:url('${p.cover}')"></div>
        <div class="shade"></div>
        <div class="content">
          <div class="meta">
            <span>${escapeHtml(p.dateLabel)}</span>
            <span>·</span>
            <span>${escapeHtml(p.category)}</span>
          </div>
          <h2 class="title">${escapeHtml(p.title)}</h2>
          <p class="desc">${escapeHtml(p.description || "")}</p>
        </div>
      </a>
    `;
  }

  function pagerHTML(page, pages) {
    if (pages <= 1) return "";

    const btn = (p, text, current=false) => `
      <button class="pagebtn" type="button" data-page="${p}" ${current ? 'aria-current="page"' : ""}>
        ${text}
      </button>
    `;

    const parts = [];
    const prev = Math.max(1, page - 1);
    const next = Math.min(pages, page + 1);

    parts.push(btn(prev, "←", false));

    // windowed pagination
    const windowSize = 5;
    let start = Math.max(1, page - Math.floor(windowSize/2));
    let end = Math.min(pages, start + windowSize - 1);
    start = Math.max(1, end - windowSize + 1);

    if (start > 1) parts.push(btn(1, "1", page === 1));

    if (start > 2) parts.push(`<span class="pill">…</span>`);

    for (let p = start; p <= end; p++) {
      parts.push(btn(p, String(p), p === page));
    }

    if (end < pages - 1) parts.push(`<span class="pill">…</span>`);

    if (end < pages) parts.push(btn(pages, String(pages), page === pages));

    parts.push(btn(next, "→", false));
    return parts.join("");
  }

  function formatDateFR(iso) {
    // iso: AAAA-MM-JJ
    const d = new Date(iso + "T00:00:00");
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleDateString("fr-FR", { day:"2-digit", month:"short", year:"numeric" }).replace(".", "");
  }

  function daysBetweenISO(iso, now) {
    const d = new Date(iso + "T00:00:00");
    if (isNaN(d.getTime())) return 99999;
    const ms = now.getTime() - d.getTime();
    return Math.floor(ms / (1000*60*60*24));
  }

  function clamp(x, a, b){ return Math.max(a, Math.min(b, x)); }

  function escapeHtml(s){
    return String(s).replace(/[&<>"']/g, m => ({
      "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
    }[m]));
  }

  function escAttr(s){ return escapeHtml(s).replace(/"/g, "&quot;"); }

  function showBanner(msg, type){
    if (!el.banner) return;
    el.banner.hidden = false;
    el.bannerMsg.textContent = msg;
    el.bannerLink.href = API_URL;
  }
  function hideBanner(){
    if (!el.banner) return;
    el.banner.hidden = true;
  }
})();
