#!/usr/bin/env python3
import argparse, re
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

def make_og(title: str, out_path: Path):
  W, H = 1200, 630
  bg = Image.new("RGB", (W, H), (8, 26, 42))
  overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
  d = ImageDraw.Draw(overlay)
  d.ellipse((-240, -300, 760, 620), fill=(48, 146, 220, 80))
  d.ellipse((360, -260, 1400, 700), fill=(54, 196, 170, 65))
  bg = Image.alpha_composite(bg.convert("RGBA"), overlay).convert("RGB")

  draw = ImageDraw.Draw(bg)
  try:
    ft = ImageFont.truetype("DejaVuSans.ttf", 56)
  except:
    ft = ImageFont.load_default()

  words = (title or "").split()
  lines, line = [], ""
  for w in words:
    test = (line + " " + w).strip()
    if draw.textlength(test, font=ft) > 980:
      if line: lines.append(line)
      line = w
    else:
      line = test
  if line: lines.append(line)
  lines = lines[:3]

  y = 260
  for ln in lines:
    draw.text((110, y), ln, font=ft, fill=(238, 246, 251))
    y += 68

  out_path.parent.mkdir(parents=True, exist_ok=True)
  bg.save(out_path, quality=92)

def extract_title(idx: Path, fallback: str):
  txt = idx.read_text(encoding="utf-8", errors="ignore")
  m = re.search(r"<h1[^>]*>(.*?)</h1>", txt, flags=re.S|re.I)
  if m:
    t = re.sub(r"<[^>]+>", "", m.group(1)).strip()
    return t or fallback
  return fallback

def main():
  ap = argparse.ArgumentParser()
  ap.add_argument("--blog-dir", required=True)
  args = ap.parse_args()

  blog_dir = Path(args.blog_dir).resolve()
  for a in blog_dir.iterdir():
    if not a.is_dir(): 
      continue
    if a.name.startswith(".") or a.name.startswith("_"):
      continue
    idx = a / "index.html"
    title = extract_title(idx, a.name) if idx.exists() else a.name
    out = a / "assets" / "img" / "og.jpg"
    make_og(title, out)
    print("OK:", out)

if __name__ == "__main__":
  main()