#!/usr/bin/env python3
CTM Blog V5 —haut game
Usage:
  python generate-articles.py --blog-dir "C:\xampp\htdocs\blog" --base-url "https://clprepas.com/blog"
Output:
  articles.json written inside blog-dir (or --out)

import argparse, json, re
from pathlib import Path
from datetime import datetime
from bs4 import BeautifulSoup

MONTHS = {
  "janvier":1,"février":2,"fevrier":2,"mars":3,"avril":4,"mai":5,"juin":6,
  "juillet":7,"août":8,"aout":8,"septembre":9,"octobre":10,"novembre":11,"décembre":12,"decembre":12
}

def parse_fr_date(text: str):
  if not text:
    return None
  t = text.lower()
  m = re.search(r"\b(\d{1,2})\s+(janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre)\s+(20\d{2})\b", t)
  if not m:
    return None
  d = int(m.group(1)); mo = MONTHS[m.group(2)]; y = int(m.group(3))
  try:
    return datetime(y, mo, d).date().isoformat()
  except:
    return None

def infer_category(slug, title, desc):
  s = f"{slug} {title} {desc}".lower()
  if any(k in s for k in ["ia", "deepseek", "manus", "github", "copilot", "gemini", "grok"]):
    return "IA"
  if any(k in s for k in ["détachement", "detachement", "lâcher", "lacher", "contrôle", "controle", "guérison", "meditation"]):
    return "Bien-être"
  if any(k in s for k in ["raison", "relations", "limites"]):
    return "Relations"
  if any(k in s for k in ["vision", "supra", "transformation", "chemin"]):
    return "Vision"
  if any(k in s for k in ["gen z", "génération", "generation"]):
    return "Société"
  return "CTM"

def pick_image(slug):
  # Prefer common OG paths used in your packs
  candidates = [
    f"/blog/{slug}/assets/img/og.jpg",
    f"/blog/{slug}/assets/img/og.png",
    f"/blog/{slug}/assets/og/og.png",
    f"/blog/{slug}/assets/og/og.webp",
    f"/blog/{slug}/assets/img/og-image.png",
    f"/blog/{slug}/assets/logo-ctm.png",
  ]
  return candidates[0]
def pick_image(slug, article_dir: Path):
  local_candidates = [
    article_dir / "assets" / "img" / "og.jpg",
    article_dir / "assets" / "img" / "og.png",
    article_dir / "assets" / "img" / "og.webp",
    article_dir / "assets" / "img" / "hero.jpg",
    article_dir / "assets" / "img" / "hero.png",
  ]
  for p in local_candidates:
    if p.exists():
      return f"/blog/{slug}/" + str(p.relative_to(article_dir)).replace("\\","/")
  return "/blog/assets/img/thumb.jpg"
def parse_article_dir(article_dir: Path, base_url: str):
  slug = article_dir.name
  # main file
  idx = article_dir / "index.html"
  if not idx.exists():
    htmls = list(article_dir.glob("*.html"))
    idx = htmls[0] if htmls else None
  if not idx:
    return None

  html = idx.read_text(encoding="utf-8", errors="ignore")
  soup = BeautifulSoup(html, "html.parser")

  # title
  title = None
  h1 = soup.find("h1")
  if h1 and h1.get_text(strip=True):
    title = h1.get_text(" ", strip=True)
  if not title and soup.title and soup.title.string:
    title = soup.title.string.strip()
  title = title or slug

  # description
  desc = ""
  md = soup.find("meta", attrs={"name":"description"})
  if md and md.get("content"):
    desc = md["content"].strip()
  ogd = soup.find("meta", property="og:description")
  if ogd and ogd.get("content") and (not desc or len(desc) < 25):
    desc = ogd["content"].strip()

  # canonical
  canonical = f"{base_url.rstrip('/')}/{slug}/"
  can = soup.find("link", rel=lambda x: x and "canonical" in x)
  if can and can.get("href"):
    canonical = can["href"].strip()

  # date
  date_iso = parse_fr_date(title) or parse_fr_date(desc) or ""
  # label
  date_label = ""
  if date_iso:
    y, m, d = date_iso.split("-")
    date_label = f"{d}/{m}/{y}"

  category = infer_category(slug, title, desc)
  image = pick_image(slug, article_dir)

  return {
    "id": slug,
    "title": title,
    "url": f"/blog/{slug}/",
    "dateISO": date_iso,
    "dateLabel": date_label,
    "category": category,
    "description": desc,
    "tags": [],
    "image": image,
    "readingMinutes": None
  }

def main():
  ap = argparse.ArgumentParser()
  ap.add_argument("--blog-dir", required=True, help="Local path to /blog folder (contains article subfolders).")
  ap.add_argument("--base-url", default="https://clprepas.com/blog", help="Base URL used for canonical fallback.")
  ap.add_argument("--out", default="", help="Output path for articles.json. Default: <blog-dir>/articles.json")
  args = ap.parse_args()

  blog_dir = Path(args.blog_dir).resolve()
  out_path = Path(args.out).resolve() if args.out else (blog_dir / "articles.json")

  if not blog_dir.exists():
    raise SystemExit(f"Blog dir not found: {blog_dir}")

  items = []
  for child in sorted(blog_dir.iterdir()):
    if not child.is_dir():
      continue
    if child.name.startswith(".") or child.name.startswith("_"):
      continue
    info = parse_article_dir(child, args.base_url)
    if info:
      items.append(info)

  items.sort(key=lambda x: (x.get("dateISO") or ""), reverse=True)

  out_path.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
  print(f"OK: wrote {out_path} ({len(items)} articles)")

if __name__ == "__main__":
  main()
