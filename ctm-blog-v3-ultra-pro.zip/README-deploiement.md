# CTM Blog V3 — Ultra Pro

Base URL
https://clprepas.com/blog/

## Déploiement (cPanel)
1) Uploader les fichiers dans /public_html/blog/
2) Vérifier:
- https://clprepas.com/blog/
- Chargement articles.json
- Recherche, filtres, pagination

## Ajouter un article
Modifier articles.json.
Champs recommandés:
- id, title, url, dateLabel, dateISO, category, description
Optionnel:
- tags, image, readingMinutes

## Fonctions V3
- Recherche instantanée
- Filtre multi-catégories (chips)
- Badge Nouveau (7 jours)
- Tri récent/ancien
- Pagination (9 cartes/page)
- Fallback image automatique