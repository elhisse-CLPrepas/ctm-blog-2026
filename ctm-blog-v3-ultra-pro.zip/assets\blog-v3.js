(() => {
  const NEW_DAYS = 7;
  const PAGE_SIZE = 9;

  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

  const grid = $("#articlesGrid");
  const search = $("#searchInput");
  const chipsWrap = $("#chipsWrap");
  const resultsPill = $("#resultsPill");
  const empty = $("#emptyState");
  const sortBtn = $("#sortBtn");
  const resetBtn = $("#resetBtn");
  const pager = $("#pager");

  const kpiTotal = $("#kpiTotal");
  const kpiCats = $("#kpiCats");
  const kpiNew = $("#kpiNew");

  const now = new Date();
  let all = [];
  let sortDesc = true;
  let selectedCats = new Set();
  let page = 1;

  const normalize = (s) =>
    (s || "")
      .toString()
      .toLowerCase()
      .normalize("NFD")
      .replace(/\p{Diacritic}/gu, "");

  const daysBetween = (iso) => {
    if (!iso) return 9999;
    const d = new Date(iso);
    const diff = now.getTime() - d.getTime();
    return Math.floor(diff / (1000 * 60 * 60 * 24));
  };

  const isNew = (iso) => {
    const d = daysBetween(iso);
    return d >= 0 && d <= NEW_DAYS;
  };

  const buildChips = (items) => {
    const cats = Array.from(new Set(items.map(x => x.category).filter(Boolean)))
      .sort((a,b)=> a.localeCompare(b, "fr"));

    kpiCats.textContent = String(cats.length);

    chipsWrap.innerHTML = "";
    const allChip = document.createElement("button");
    allChip.className = "chip";
    allChip.type = "button";
    allChip.textContent = "Toutes";
    allChip.setAttribute("aria-pressed", "true");
    allChip.dataset.cat = "__all__";
    chipsWrap.appendChild(allChip);

    cats.forEach(c => {
      const b = document.createElement("button");
      b.className = "chip";
      b.type = "button";
      b.textContent = c;
      b.setAttribute("aria-pressed", "false");
      b.dataset.cat = c;
      chipsWrap.appendChild(b);
    });

    chipsWrap.addEventListener("click", (e) => {
      const btn = e.target.closest(".chip");
      if (!btn) return;

      const cat = btn.dataset.cat;

      if (cat === "__all__") {
        selectedCats.clear();
        $$(".chip", chipsWrap).forEach(x =>
          x.setAttribute("aria-pressed", x.dataset.cat === "__all__" ? "true" : "false")
        );
        page = 1;
        render();
        return;
      }

      const allBtn = $$(".chip", chipsWrap).find(x => x.dataset.cat === "__all__");
      if (allBtn) allBtn.setAttribute("aria-pressed", "false");

      if (selectedCats.has(cat)) {
        selectedCats.delete(cat);
        btn.setAttribute("aria-pressed", "false");
      } else {
        selectedCats.add(cat);
        btn.setAttribute("aria-pressed", "true");
      }

      if (selectedCats.size === 0) {
        if (allBtn) allBtn.setAttribute("aria-pressed", "true");
      }

      page = 1;
      render();
    });
  };

  const updateKPIs = (items) => {
    kpiTotal.textContent = String(items.length);
    kpiNew.textContent = String(items.filter(a => isNew(a.dateISO)).length);
  };

  const matches = (a, q) => {
    if (selectedCats.size > 0 && !selectedCats.has(a.category)) return false;
    if (!q) return true;

    const hay = [
      a.title, a.description, a.category,
      ...(Array.isArray(a.tags) ? a.tags : [])
    ].map(normalize).join(" | ");

    return hay.includes(q);
  };

  const sortItems = (items) => {
    const copy = [...items];
    copy.sort((x, y) => {
      const dx = (x.dateISO || "");
      const dy = (y.dateISO || "");
      if (dx === dy) return (x.title || "").localeCompare((y.title || ""), "fr");
      return sortDesc ? dy.localeCompare(dx) : dx.localeCompare(dy);
    });
    return copy;
  };

  const cardHTML = (a) => {
    const safeTitle = a.title || "Sans titre";
    const safeUrl = a.url || "#";
    const safeDesc = a.description || "";
    const mins = a.readingMinutes ? `${a.readingMinutes} min` : "";
    const img = a.image ? a.image : "assets/img/hero.png";

    const tags = Array.isArray(a.tags) ? a.tags.slice(0, 3) : [];
    const tagBadges = tags.map(t => `<span class="badge">${t}</span>`).join("");

    return `
      <article class="card reveal">
        <div class="media">
          <img src="${img}" alt="${safeTitle}" loading="lazy" onerror="this.src='assets/img/hero.png'">
        </div>
        <div class="body">
          <h3 class="title">${safeTitle}</h3>
          <div class="meta">
            <span>${a.dateLabel || "—"}</span>
            <span>·</span>
            <span>${a.category || "—"}</span>
            ${mins ? `<span>·</span><span>${mins}</span>` : ``}
          </div>

          <div class="badges">
            ${isNew(a.dateISO) ? `<span class="badge new">Nouveau</span>` : ``}
            ${a.category ? `<span class="badge cat">${a.category}</span>` : ``}
            ${tagBadges}
          </div>

          <p class="desc">${safeDesc}</p>

          <div class="actions">
            <a href="${safeUrl}">Lire l’article <span aria-hidden="true">→</span></a>
            <div class="small">${a.id || ""}</div>
          </div>
        </div>
      </article>
    `;
  };

  const renderPager = (total) => {
    const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    page = Math.min(page, totalPages);
    pager.innerHTML = "";

    const mk = (label, p, disabled=false, active=false) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "page-btn" + (active ? " active" : "");
      b.textContent = label;
      if (disabled) b.disabled = true;
      b.addEventListener("click", () => {
        page = p;
        render();
        window.scrollTo({ top: 0, behavior: "smooth" });
      });
      return b;
    };

    pager.appendChild(mk("«", 1, page === 1));
    pager.appendChild(mk("‹", page - 1, page === 1));

    const win = 2;
    const start = Math.max(1, page - win);
    const end = Math.min(totalPages, page + win);

    for (let p = start; p <= end; p++) {
      pager.appendChild(mk(String(p), p, false, p === page));
    }

    pager.appendChild(mk("›", page + 1, page === totalPages));
    pager.appendChild(mk("»", totalPages, page === totalPages));
  };

  const reveal = () => {
    const cards = $$(".reveal", grid);
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add("on");
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.12 });
    cards.forEach(c => io.observe(c));
  };

  const render = () => {
    const q = normalize(search.value.trim());
    const filtered = sortItems(all.filter(a => matches(a, q)));

    const total = filtered.length;
    resultsPill.textContent = `${total} ${total <= 1 ? "résultat" : "résultats"}`;

    if (total === 0) {
      grid.innerHTML = "";
      empty.hidden = false;
      pager.innerHTML = "";
      return;
    }

    empty.hidden = true;

    const start = (page - 1) * PAGE_SIZE;
    const slice = filtered.slice(start, start + PAGE_SIZE);

    grid.innerHTML = slice.map(cardHTML).join("");
    renderPager(total);
    reveal();
  };

  const reset = () => {
    search.value = "";
    selectedCats.clear();
    page = 1;
    $$(".chip", chipsWrap).forEach(x =>
      x.setAttribute("aria-pressed", x.dataset.cat === "__all__" ? "true" : "false")
    );
    render();
    search.focus();
  };

  const init = async () => {
    try{
      const res = await fetch("articles.json", { cache:"no-store" });
      if(!res.ok) throw new Error("articles.json introuvable");
      all = await res.json();

      updateKPIs(all);
      buildChips(all);
      render();

      search.addEventListener("input", () => { page = 1; render(); });

      sortBtn.addEventListener("click", () => {
        sortDesc = !sortDesc;
        sortBtn.textContent = sortDesc ? "Trier: récent → ancien" : "Trier: ancien → récent";
        sortBtn.setAttribute("aria-pressed", String(!sortDesc));
        render();
      });

      resetBtn.addEventListener("click", reset);
    }catch(e){
      grid.innerHTML = "";
      empty.hidden = false;
      empty.textContent = "Impossible de charger articles.json. Vérifiez le fichier et ses permissions.";
      resultsPill.textContent = "0 résultat";
      kpiTotal.textContent = "0";
      kpiCats.textContent = "0";
      kpiNew.textContent = "0";
    }
  };

  init();
})();